"""
DS-Router v1: Model Router with Intelligence Routing
==================================================
"""

from __future__ import annotations
import asyncio
import re
import logging
import os
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

from .providers import (
    BaseProvider, GenRequest, GenResponse,
    DeepSeekChatProvider, DeepSeekThinkingProvider, 
    DeepSeekR1Provider, QwenCPUProvider
)

try:
    from ..safety.pre_guard import PreGuard
    from ..safety.post_guard import PostGuard
except ImportError:
    PreGuard = None
    PostGuard = None

log = logging.getLogger(__name__)

@dataclass
class RouterConfig:
    """Configuration for the DS-Router."""
    conf_threshold: float = 0.62
    support_threshold: float = 0.55
    max_cot_tokens: int = 6000
    max_oracle_tokens_per_day: int = 250000
    max_oracle_usd_per_day: float = 50.0
    budget_enforcement: str = "hard"  # hard|warn
    
    # Provider configurations
    deepseek_api_key: Optional[str] = None
    hf_token: Optional[str] = None

    # Features
    enable_r1_escalation: bool = False

    # Timeouts (seconds)
    provider_timeout_secs: float = 8.0
    r1_timeout_secs: float = 30.0
    health_timeout_secs: float = 8.0
    pre_guard_timeout_secs: float = 1.0
    post_guard_timeout_secs: float = 1.5
    
    @classmethod
    def from_env(cls) -> 'RouterConfig':
        """Load configuration from environment variables."""
        return cls(
            conf_threshold=float(os.getenv("CONF_THRESHOLD", "0.62")),
            support_threshold=float(os.getenv("SUPPORT_THRESHOLD", "0.55")),
            max_cot_tokens=int(os.getenv("MAX_COT_TOKENS", "6000")),
            max_oracle_tokens_per_day=int(os.getenv("MAX_ORACLE_TOKENS_PER_DAY", "250000")),
            max_oracle_usd_per_day=float(os.getenv("MAX_ORACLE_USD_PER_DAY", "50.0")),
            budget_enforcement=os.getenv("BUDGET_ENFORCEMENT", "hard"),
            deepseek_api_key=os.getenv("DEEPSEEK_API_KEY"),
            hf_token=os.getenv("HF_TOKEN"),
            enable_r1_escalation=str(os.getenv("ENABLE_R1_ESCALATION", "false")).lower() in ("1", "true", "yes"),
            provider_timeout_secs=float(os.getenv("PROVIDER_TIMEOUT_SECS", "8")),
            r1_timeout_secs=float(os.getenv("R1_TIMEOUT_SECS", "30")),
            health_timeout_secs=float(os.getenv("PROVIDER_HEALTH_TIMEOUT_SECS", "8")),
            pre_guard_timeout_secs=float(os.getenv("PRE_GUARD_TIMEOUT_SECS", "1.0")),
            post_guard_timeout_secs=float(os.getenv("POST_GUARD_TIMEOUT_SECS", "1.5")),
        )

class DSRouter:
    """Intelligent model router with safety and fallback capabilities."""
    
    def __init__(self, config: RouterConfig = None):
        self.config = config or RouterConfig.from_env()
        self.logger = logging.getLogger(__name__)
        
        # Initialize providers
        self.providers: Dict[str, BaseProvider] = {}
        self._initialize_providers()
        
        # Initialize safety guards
        self.pre_guard = PreGuard() if PreGuard else None
        self.post_guard = PostGuard() if PostGuard else None
        
        # Budget tracking (should use Redis in production)
        self._budget_tracker = BudgetTracker(self.config)
        
        # Compile regex patterns for hard problem detection
        self._hard_patterns = self._compile_hard_patterns()
        
    def _initialize_providers(self):
        """Initialize all available providers."""
        try:
            # DeepSeek providers
            deepseek_config = {"api_key": self.config.deepseek_api_key}
            
            self.providers["deepseek_chat"] = DeepSeekChatProvider(deepseek_config)
            self.providers["deepseek_thinking"] = DeepSeekThinkingProvider(deepseek_config)
            self.providers["deepseek_r1"] = DeepSeekR1Provider(deepseek_config)
            
            # Local fallback
            qwen_config = {"hf_token": self.config.hf_token}
            self.providers["qwen_cpu"] = QwenCPUProvider(qwen_config)
            
            self.logger.info("Initialized DS-Router with providers: %s", list(self.providers.keys()))
            
        except Exception as e:
            self.logger.error(f"Failed to initialize providers: {e}")
    
    def _compile_hard_patterns(self) -> List[re.Pattern]:
        """Compile regex patterns for detecting hard problems."""
        patterns = [
            # Math and logic
            r'\b(prove|derive|optimize|constraints?)\b',
            r'\b(induction|deduction|axiom|theorem)\b',
            r'\b(NP-complete|complexity|Big-O|algorithm)\b',
            
            # Code and technical
            r'\b(regex|regular expression|compiler|parser)\b',
            r'\b(unit test|test case|debugging)\b',
            r'\b(refactor|optimize code|performance)\b',
            
            # Complex reasoning
            r'\b(paradox|contradiction|logical fallacy)\b',
            r'\b(multi-step|step-by-step|systematic)\b',
            r'\b(analyze|compare|evaluate|critique)\b',
            
            # Mathematical symbols and operations
            r'[∀∃∈∉∪∩⊂⊃∧∨¬→↔]',  # Logical symbols
            r'\b(integral|derivative|limit|convergence)\b',
        ]
        
        return [re.compile(pattern, re.IGNORECASE) for pattern in patterns]
    
    async def generate(self, request: GenRequest) -> GenResponse:
        """Main router entry point with full safety and intelligence routing."""
        start_time = asyncio.get_event_loop().time()
        
        # Step 1: Pre-filtering and sanitization (bounded time)
        if self.pre_guard:
            try:
                sanitized_request, pre_guard_result = await asyncio.wait_for(
                    self.pre_guard.process(request),
                    timeout=self.config.pre_guard_timeout_secs,
                )
            except Exception as e:
                log.warning("PreGuard disabled due to error/timeout: %s", e)
                sanitized_request, pre_guard_result = request, None
        else:
            sanitized_request = request
            pre_guard_result = None
        
        # Step 2: Budget check
        budget_status = await self._budget_tracker.check_budget()
        if budget_status.exceeded and self.config.budget_enforcement == "hard":
            return self._create_budget_exceeded_response(budget_status, start_time)
        
        # Step 3: Determine routing strategy
        routing_decision = await self._determine_routing(sanitized_request)
        
        # Step 4: Generate response with chosen provider (bounded time)
        try:
            response = await self._generate_with_routing(sanitized_request, routing_decision)
        except Exception as e:
            self.logger.error(f"Generation failed: {e}")
            # Fallback to local provider
            response = await self._fallback_generate(sanitized_request, str(e))
        
        # Step 5: Confidence assessment and potential escalation
        if routing_decision.provider != "qwen_cpu":
            confidence = await self._assess_confidence(response, sanitized_request)
            response.confidence = confidence
            
            if (self.config.enable_r1_escalation and confidence < self.config.conf_threshold and 
                routing_decision.provider != "deepseek_r1"):
                
                escalation_decision = RoutingDecision(
                    provider="deepseek_r1",
                    reasoning="low_confidence_escalation", 
                    cot_budget=self.config.max_cot_tokens
                )
                
                try:
                    response = await self._generate_with_routing(sanitized_request, escalation_decision)
                    response.confidence = await self._assess_confidence(response, sanitized_request)
                    response.metadata["escalated"] = True
                    response.metadata["escalation_reason"] = "low_confidence"
                except Exception as e:
                    self.logger.warning(f"Escalation to R1 failed: {e}")
        
        # Step 6: Post-filtering and verification (bounded time)
        if self.post_guard:
            try:
                final_response, post_guard_result = await asyncio.wait_for(
                    self.post_guard.process(response, sanitized_request),
                    timeout=self.config.post_guard_timeout_secs,
                )
            except Exception as e:
                log.warning("PostGuard disabled due to error/timeout: %s", e)
                final_response, post_guard_result = response, None
        else:
            final_response = response
            post_guard_result = None
        
        # Step 7: Budget tracking and audit logging
        await self._budget_tracker.record_usage(final_response)
        await self._audit_log(sanitized_request, final_response, routing_decision, pre_guard_result, post_guard_result)
        
        return final_response
    
    async def _determine_routing(self, request: GenRequest) -> 'RoutingDecision':
        """Determine which provider to use based on request characteristics."""
        # Hard detection
        is_hard = self._is_hard_problem(request.prompt)
        support_score = 0.7  # Placeholder; can be wired to real RAG
        if support_score < self.config.support_threshold:
            is_hard = True
        if not is_hard:
            return RoutingDecision(provider="deepseek_chat", reasoning="simple_query", cot_budget=None)
        else:
            return RoutingDecision(provider="deepseek_thinking", reasoning="complex_query", cot_budget=min(self.config.max_cot_tokens, 3000))
    
    def _is_hard_problem(self, prompt: str) -> bool:
        for pattern in self._hard_patterns:
            if pattern.search(prompt):
                return True
        return False
    
    async def _generate_with_routing(self, request: GenRequest, decision: 'RoutingDecision') -> GenResponse:
        provider = self.providers.get(decision.provider)
        if not provider:
            raise ValueError(f"Provider {decision.provider} not available")
        if decision.cot_budget:
            request.cot_budget = decision.cot_budget
        # Use longer timeout for R1
        timeout_secs = self.config.r1_timeout_secs if decision.provider == "deepseek_r1" else self.config.provider_timeout_secs
        try:
            response = await asyncio.wait_for(provider.generate(request), timeout=timeout_secs)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Provider {decision.provider} timed out after {timeout_secs}s")
        response.metadata.update({"routing_decision": decision.provider, "routing_reasoning": decision.reasoning})
        return response
    
    async def _fallback_generate(self, request: GenRequest, error: str) -> GenResponse:
        qwen_provider = self.providers.get("qwen_cpu")
        if qwen_provider:
            try:
                response = await asyncio.wait_for(qwen_provider.generate(request), timeout=self.config.provider_timeout_secs)
            except Exception as e:
                return GenResponse(
                    content="I apologize, but I'm currently unable to process your request due to system limitations.",
                    provider="system_fallback",
                    metadata={"error": str(e), "ultimate_fallback": True}
                )
            response.metadata["fallback_reason"] = error
            return response
        else:
            return GenResponse(
                content="I apologize, but I'm currently unable to process your request due to system limitations.",
                provider="system_fallback",
                metadata={"error": error, "ultimate_fallback": True}
            )
    
    async def _assess_confidence(self, response: GenResponse, request: GenRequest) -> float:
        confidence = 0.7
        if len(response.content) < 50:
            confidence -= 0.2
        elif len(response.content) > 500:
            confidence += 0.1
        if response.provider.startswith("deepseek_r1"):
            confidence += 0.2
        elif response.provider.startswith("deepseek_thinking"):
            confidence += 0.1
        elif response.provider.startswith("qwen_cpu"):
            confidence -= 0.3
        uncertainty_markers = ["i'm not sure", "i don't know", "uncertain", "maybe", "possibly"]
        content_lower = response.content.lower()
        for marker in uncertainty_markers:
            if marker in content_lower:
                confidence -= 0.15
                break
        return max(0.0, min(1.0, confidence))
    
    def _create_blocked_response(self, reason: str, start_time: float) -> GenResponse:
        latency_ms = (asyncio.get_event_loop().time() - start_time) * 1000
        return GenResponse(
            content="I cannot provide a response to this request due to safety or policy restrictions.",
            provider="safety_filter",
            latency_ms=latency_ms,
            metadata={"blocked": True, "block_reason": reason}
        )
    
    def _create_budget_exceeded_response(self, budget_status: 'BudgetStatus', start_time: float) -> GenResponse:
        latency_ms = (asyncio.get_event_loop().time() - start_time) * 1000
        return GenResponse(
            content=f"Daily budget limit has been exceeded. Service will resume at {budget_status.next_reset_utc}.",
            provider="budget_limiter",
            latency_ms=latency_ms,
            metadata={
                "budget_exceeded": True,
                "next_reset": budget_status.next_reset_utc,
                "usage_tokens": budget_status.tokens_used,
                "usage_usd": budget_status.usd_spent
            }
        )
    
    async def _audit_log(self, request: GenRequest, response: GenResponse, routing: 'RoutingDecision', pre_guard=None, post_guard=None):
        audit_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "input_sha256": self._hash_content(request.prompt),
            "provider": response.provider,
            "confidence": response.confidence,
            "routing_decision": routing.provider,
            "routing_reasoning": routing.reasoning,
            "blocked": response.metadata.get("blocked", False),
            "escalated": response.metadata.get("escalated", False),
            "filters": {
                "pre_guard": getattr(pre_guard, 'status', 'disabled') if pre_guard else "disabled",
                "post_guard": getattr(post_guard, 'status', 'disabled') if post_guard else "disabled"
            },
            "tokens": {"prompt": response.prompt_tokens, "output": response.output_tokens},
            "cost_usd": response.cost_usd,
            "latency_ms": response.latency_ms
        }
        self.logger.info("Audit log", extra={"audit": audit_entry})
    
    def _hash_content(self, content: str) -> str:
        import hashlib
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    async def get_provider_status(self) -> Dict[str, Any]:
        status = {}
        for name, provider in self.providers.items():
            try:
                health = await asyncio.wait_for(provider.health_check(), timeout=self.config.health_timeout_secs)
                status[name] = health
            except Exception as e:
                status[name] = {"status": "error", "error": str(e)}
        return status

@dataclass
class RoutingDecision:
    provider: str
    reasoning: str
    cot_budget: Optional[int] = None

@dataclass 
class BudgetStatus:
    exceeded: bool
    tokens_used: int
    usd_spent: float
    next_reset_utc: str

class BudgetTracker:
    def __init__(self, config: RouterConfig):
        self.config = config
        self.tokens_used = 0
        self.usd_spent = 0.0
        
    async def check_budget(self) -> BudgetStatus:
        exceeded = (
            self.tokens_used >= self.config.max_oracle_tokens_per_day or
            self.usd_spent >= self.config.max_oracle_usd_per_day
        )
        from datetime import datetime, timedelta
        next_reset = (datetime.utcnow() + timedelta(days=1)).strftime("%Y-%m-%d 00:00:00 UTC")
        return BudgetStatus(
            exceeded=exceeded,
            tokens_used=self.tokens_used,
            usd_spent=self.usd_spent,
            next_reset_utc=next_reset
        )
    
    async def record_usage(self, response: GenResponse):
        self.tokens_used += response.prompt_tokens + response.output_tokens
        self.usd_spent += response.cost_usd