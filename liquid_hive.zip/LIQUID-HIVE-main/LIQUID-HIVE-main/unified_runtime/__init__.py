"""Unified runtime package for the Apex Hive‑Mind.

This package exposes the FastAPI server entry point in ``server.py`` and
other helpers such as the context bridge and dynamic strategy selector.
"""