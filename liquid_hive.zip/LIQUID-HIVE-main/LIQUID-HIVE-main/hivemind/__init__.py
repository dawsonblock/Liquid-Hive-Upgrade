"""HiveMind package placeholder for training modules.
This minimal package enables running modules via `python -m hivemind.training.sft_text`.
"""