"""Autonomy modules for HiveMind.

Includes:
- orchestrator: main autonomy orchestrator (optional in this build)
- curiosity: CuriosityEngine (Genesis Spark) for self-directed inquiry
"""